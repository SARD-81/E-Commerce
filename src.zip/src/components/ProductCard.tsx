import EditIcon from "@mui/icons-material/Edit";
import KeyboardBackspaceIcon from "@mui/icons-material/KeyboardBackspace";
import shoppingCard from "../assets/shop.svg";
import { Box, Button, IconButton, Typography } from "@mui/material";
import FavoriteItem from "./heartButton";
import type { ProductResponseType } from "../types/Product";

interface ProductCardProps {
  product: ProductResponseType;
  productId: number | string;
  title: string;
  price: number;
  description: string;
  imageSrc: string;
  onEdit?: (productId: string | number) => void;
  onShowMore?: (productId: number | string) => void;
  onAddToBasket?: (productId: number | string) => void;
}

export default function wProductCard({
  product,
  productId,
  title,
  price,
  description,
  imageSrc,
  onEdit,
  onShowMore,
  onAddToBasket,
}: ProductCardProps) {
  const handleToggleFavorite = (
    itemId: string | number,
    isFavorite: boolean
  ) => {
    console.log(itemId, isFavorite);
  };

  return (
    <Box sx={{ width: "384px" }}>
      <Box
        sx={{
          borderTopLeftRadius: "6px",
          borderTopRightRadius: "6px",
          display: "flex",
          alignItems: "center",
          justifyContent: "center",
          height: "170px",
          overflow: "hidden",
          position: "relative",
        }}
      >
        <Box component="img" src={imageSrc} alt="product-picture" />
      </Box>

      <Box
        sx={{
          borderBottomLeftRadius: "6px",
          borderBottomRightRadius: "6px",
          backgroundColor: "#1F2937",
          display: "flex",
          flexDirection: "column",
          gap: "16px",
          padding: "16px",
        }}
      >
        <Box
          sx={{
            display: "flex",
            justifyContent: "space-between",
          }}
        >
          <Typography component="p" variant="body1" sx={{ color: "#DB2777" }}>
            {price} تومان
          </Typography>
          <Typography
            component="p"
            variant="body1"
            sx={{ color: "#FFFFFF", fontSize: "20px", fontWeight: "bold" }}
          >
            {title}
          </Typography>
        </Box>
        <Typography className="text-[#9CA3AF] text-right">
          {description}
        </Typography>
        <Box className=" flex justify-between ">
          <Box
            component="img"
            sx={{
              borderRadius: "12px",
              marginBottom: "16px",
              backgroundColor: "#797979",
            }}
            src={shoppingCard}
            alt="product_card"
            onClick={() => onAddToBasket?.(productId)}
          />
          <IconButton
            aria-label="edit"
            onClick={() => onEdit?.(productId)}
            sx={{
              position: "absolute",
              top: 8,
              right: 8,
              backgroundColor: "rgba(0, 0, 0, 0.5)",
              color: "white",
              "&:hover": {
                backgroundColor: "rgba(0, 0, 0, 0.7)",
              },
            }}
          >
            <EditIcon fontSize="small" />
            <FavoriteItem
              product={product}
              onToggleFavorite={handleToggleFavorite}
            />
          </IconButton>
          <Button
            variant="contained"
            sx={{
              color: "#FFFFFF",
              backgroundColor: "#DB2777",
            }}
            onClick={() => onShowMore?.(productId)}
          >
            <KeyboardBackspaceIcon /> مشاهده بیشتر{" "}
          </Button>
        </Box>
      </Box>
    </Box>
  );
}
