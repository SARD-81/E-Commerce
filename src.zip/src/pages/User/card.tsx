

const Card = () => {
    return(
        <div></div>
    );
}

export default Card;