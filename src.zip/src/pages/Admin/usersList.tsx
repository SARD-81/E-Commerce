import AdminMenu from "../../components/AdminMenu"


const UsersList = () => {
    return(
        <div>
            <AdminMenu/>
            <ul>
                
            </ul>
        </div>
    )
}


export default UsersList
