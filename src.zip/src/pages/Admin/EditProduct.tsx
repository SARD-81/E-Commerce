import { useForm } from "react-hook-form";
import type { IEditProduct } from "../../hooks/useEditProduct";
import useGetAllCategories from "../../hooks/useCategories";
import useUploadImgae from "../../hooks/useUploadImage";
import useUploadImage from "../../hooks/useUploadImage";
import { useParams } from "react-router-dom";
import useProduct from "../../hooks/useProducts";
import useProducts from "../../hooks/useProducts";
import useEditProduct from "../../hooks/useEditProduct";
import Preloader from "../../components/Preloader";
import {
  Box,
  Container,
  FormControl,
  InputLabel,
  MenuItem,
  Select,
  Typography,
} from "@mui/material";
import UploadImage from "./ProductUploadImage";

const EditProduct = () => {
  const {
    register,
    handleSubmit,
    formState: { errors },
  } = useForm<IEditProduct>();
  const { data: categories } = useGetAllCategories();
  const { mutate: deleteProduct } = useDeleteProduct();
  const { mutate: uploadImage, data: uploadedImage } = useUploadImage();
  const { id } = useParams();
  const { data: products, isLoading } = useProducts();
  const product = products?.find((product) => product._id === id);
  const { mutate } = useEditProduct(uploadedImage?.image);

  const onSubmit = (data: IEditProduct) => {
    mutate(data);
  };

  function handleDelete(): void {
    deleteProduct();
  }
  if (isLoading) <Preloader />;

  return (
    <Container maxWidth="md">
      <Box
        component="section"
        sx={{
          display: "flex",
          flexDirection: "column",
          gap: 6,
          mt: 4,
        }}
      >
        <Typography variant="h5">محصول جدید</Typography>
        <form
          onSubmit={handleSubmit(onSubmit)}
          className="flex flex-col w-full gap-6"
        >
          <Box component="div">
            <UploadImage onUploadImage={(file) => uploadImage(file)} />
          </Box>
          <Box>
            <label htmlFor="productName">نام</label>
            <input
              id="name"
              {...register("name", {
                required: true,
                minLength: 3,
              })}
              placeholder="نام محصول خود را وارد نمایید"
              className="w-full mt-3 p-2 outline-none border border-[#CED2D7] rounded-lg bg-white"
            />
            {errors.name?.type === "required" && (
              <p className="text-error text-sm">این فیلد اجباری است</p>
            )}
            {errors.name?.type === "minLength" && (
              <p className="text-error text-sm">حداقل باید 3 کارکتر باشد</p>
            )}
          </Box>
          <Box className="flex items-center justify-center gap-8">
            <div className="w-1/2">
              <label htmlFor="productPrice">قیمت</label>
              <input
                type="number"
                {...register("price")}
                id="productPrice"
                placeholder="قیمت محصول خود را وارد نمایید"
                className="w-full mt-3 p-2 outline-none border border-[#CED2D7] rounded-lg bg-white"
              />
            </div>
            <div className="w-1/2">
              <InputLabel
                sx={{
                  mb: "12px",
                  color: "#000",
                }}
                id="category"
              >
                دسته بندی
              </InputLabel>

              <FormControl sx={{ width: "100%" }}>
                <InputLabel id="category">دسته بندی</InputLabel>
                <Select
                  id="category"
                  label="category"
                  {...register("category")}
                >
                  {categories?.map((category) => (
                    <MenuItem key={category._id} value={category._id}>
                      {category.name}
                    </MenuItem>
                  ))}
                </Select>
              </FormControl>
            </div>
          </Box>
          <Box className="flex flex-col gap-3">
            <label htmlFor="productDesc">توضیحات</label>
            <textarea
              id="productDesc"
              rows={4}
              {...register("description")}
              placeholder="توضیحات محصول خود را وارد نمایید"
              className="w-full p-2 outline-none border border-[#CED2D7] rounded-lg bg-white resize-none"
            ></textarea>
          </Box>
          <Box className="flex items-center justify-center gap-8">
            <div className="w-1/2">
              <label htmlFor="productQuantity">تعداد قابل خرید</label>
              <input
                type="number"
                {...register("quantity")}
                id="productQuantity"
                placeholder="تعداد را وارد نمایید"
                className="w-full mt-3 p-2 outline-none border border-[#CED2D7] rounded-lg bg-white"
              />
            </div>
            <div className="w-1/2">
              <label htmlFor="productStatus">موجودی</label>
              <select
                id="productStatus"
                name="status"
                className="appearance-none cursor-pointer w-full mt-3 p-2 outline-none border border-[#CED2D7] rounded-lg bg-white"
              >
                <option value="in-stock">موجود</option>
                <option value="out-of-stock">ناموجود</option>
              </select>
            </div>
          </Box>
          <Box>
            <Button
              type="submit"
              variant="contained"
              disabled={isLoading}
              className={`${
                isLoading ? "w-[100px]" : ""
              } w-[15.5%] py-1 rounded-lg shadow-none bg-[#DB2777] whitespace-nowrap hover:bg-[#BE1D64]`}
            >
              {isLoading ? "در حال پردازش..." : "ساخت محصول جدید"}
            </Button>
          </Box>
        </form>
      </Box>
    </Container>
  );
};

export default EditProduct;
