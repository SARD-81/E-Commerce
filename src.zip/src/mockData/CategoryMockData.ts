import type { CategoryType } from "../types/Category";

export const CategoryMockData: CategoryType[] = [
  {
    _id: "6849d35484b146939019c322",
    name: "Apple",
    __v: 0,
  },
  {
    _id: "6849d35484b146939019c323",
    name: "Samsung",
    __v: 0,
  },
  {
    _id: "6849d35484b146939019c324",
    name: "Microsoft",
    __v: 0,
  },
];
