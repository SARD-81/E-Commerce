export interface CategoryType {
  _id: string;
  name: string;
  __v: number;
}
