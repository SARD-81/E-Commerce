export interface FilterProductType {
  categories: string[];
  price: number[];
}
