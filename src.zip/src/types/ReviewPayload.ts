export type ReviewPayload = {
  productId: string | number;
  comment: string;
  rating: number;
};
