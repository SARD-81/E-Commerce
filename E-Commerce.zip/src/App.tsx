import { CssBaseline, ThemeProvider } from "@mui/material";
import SideMenu from "./components/SideMenu";
import { theme } from "./theme";
import { Routes, Route } from "react-router";
import Shop from "./pages/User/Shop";
import Login from "./pages/Login/Login";
import Register from "./pages/Register/Register";
import Profile from "./pages/User/Profile";
import Dashboard from "./pages/Admin/Dashboard";
import ProductPage from "./pages/User/ProductPage";
import { AuthProvider } from "./context/AuthContext";

function App() {
  return (
    <>
      <ThemeProvider theme={theme}>
        <CssBaseline>
          <AuthProvider>
            <SideMenu>
              <Routes>
                <Route path="/" element={<ProductPage />} />
                <Route path="/shop" element={<Shop />} />
                <Route path="/cart" element={<Profile />} />
                <Route path="/wishlist" element={<Dashboard />} />
                <Route path="/login" element={<Login />} />
                <Route path="/register" element={<Register />} />
              </Routes>
            </SideMenu>
          </AuthProvider>
        </CssBaseline>
      </ThemeProvider>
    </>
  );
}

export default App;
