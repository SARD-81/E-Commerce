const Somthing = () => {};

export default Somthing;
